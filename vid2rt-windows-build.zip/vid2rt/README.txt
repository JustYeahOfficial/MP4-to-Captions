vid2rt — build instructions
=============================

WHAT THIS IS
-------------
Pick a video, it renders every frame as a grid of coloured block
characters and writes a RealText (.rt) caption file where each cue is
one frame. Upload that as a caption track on YouTube and, with
captions on, you get a small animated colour "video" playing inside
the subtitles.

Quick note on the build: I'm running in a Linux sandbox with no
Windows machine attached, so I can't hand you an already-compiled
.exe - Windows executables can only be built on Windows. What I CAN
give you is a one-click script that builds it in about a minute on
your own PC, producing exactly the "_internal folder + .exe, nothing
else" layout you asked for - verified on my end.

HOW TO BUILD IT (Windows)
--------------------------
1. Install Python 3.10+ from python.org if you don't already have it.
   During setup, tick "Add python.exe to PATH".
2. Put these 5 files in the same folder:
     video_to_rt.py
     build_prepare.py
     build.bat
     icon.ico
     requirements.txt   (not required by the script, just for reference)
3. Double-click build.bat.
   It will: install PyInstaller/Pillow/imageio-ffmpeg, copy a portable
   ffmpeg.exe into a "bin" folder, then run PyInstaller.
4. When it finishes, open the new "dist\vid2rt" folder. It contains
   only:
     vid2rt.exe
     _internal\        (everything else lives in here — ffmpeg, Python
                         runtime, Pillow, Tk, etc.)
   Copy that whole "vid2rt" folder anywhere — it's fully self-contained,
   no Python or ffmpeg install needed on the target machine.

WHAT THE APP DOES
------------------
Double-click vid2rt.exe and a file picker opens immediately. Choose
any video (mp4, mov, mkv, avi, webm, ...). It then analyses the video,
saves frames from it, converts each frame into a grid of coloured
block characters, shows "Finished!!!", and opens a Save-As dialog so
you pick where to write the .rt file.

UPLOADING TO YOUTUBE
----------------------
1. YouTube Studio → your video → Subtitles → Add language (if needed)
2. Upload file → pick the .rt file → choose "With timing"
   (NOT "Without timing" - that treats it as a plain transcript and
   discards the markup)
3. Publish, then watch on youtube.com/watch (not inside YouTube's own
   caption editor - that never shows styling, even when a track is
   working) with captions turned on.

THE BUG HUNT (what actually went wrong, and what fixed it)
--------------------------------------------------------------
This took several rounds of testing directly against real YouTube
playback to track down, because the failure (caption renders solid
white/blank) looks identical for several completely different causes.
In case future-you (or future-me) hits this again, here's the actual
trail, in order:

1. WRONG FILE FORMAT. The very first version saved .srt with <font
   color> tags. YouTube's own help page confirms plain SRT carries
   timing only, no markup - the literal "<font color=...>" text shows
   up baked into the caption. Fix: use RealText (.rt), which YouTube's
   help page explicitly lists as supporting <font color>. This is
   also why the original tool (that this app is based on) was named
   vid2"rt" in the first place.

2. Tried reducing file size (smaller grid, lower fps, rounding
   colours) on the theory the 6+ MB files we were producing were way
   outside caption-file norms. This helped file size but did NOT fix
   the actual bug - a much smaller file still came out blank.

3. Suspected a "distinct colour budget" next - a file using hundreds
   of unique colours failed, one using only 8-32 worked. But this
   turned out to be a coincidence: a synthetic test using the SAME 32
   real, muted colours from the actual video, arranged in a clean
   repeating pattern, ALSO worked fine. So colour count/vividness
   wasn't actually it either.

4. THE REAL CAUSE: total number of genuinely DIFFERENT frames in the
   file. Confirmed by testing a single real (visually complex) video
   frame held static across many cues - that worked. Then the real
   video at decreasing frame rates: 138 distinct frames failed, 124
   worked, 110 worked. So somewhere between 124-138 distinct frames
   (for this ~27 second video) is the actual ceiling - a predictable/
   repeating pattern or a frozen frame stays fine no matter how many
   cues reuse it, but genuinely novel content in every cue adds up and
   eventually YouTube's renderer just gives up and shows white.

   This means a FIXED frame rate is the wrong approach entirely -
   whatever this budget actually is, a longer video hits it at a
   LOWER fps. The app now picks fps dynamically per video so the
   TOTAL frame count stays under MAX_TOTAL_FRAMES (110, with a safety
   margin below the confirmed-good 124) no matter how long the source
   video is - see MAX_TOTAL_FRAMES in video_to_rt.py.

The colour-palette quantization from step 3 stayed in the app even
though it wasn't the fix - it's still a genuinely good idea for file
size and doesn't hurt.

UPLOADING TO GITHUB
----------------------
The built dist\vid2rt folder (vid2rt.exe + _internal) is fully
self-contained and portable - copy it anywhere and it works, no
Python or ffmpeg install needed on the target machine. That part's
fine for GitHub. A few things worth knowing before you push it,
though:

- IT'S ABOUT 126 MB. Nothing in it is over GitHub's 100 MB hard
  per-file limit (the biggest single file, the bundled ffmpeg, is
  about 77 MB), so a plain `git push` won't outright fail. But
  committing a ~126 MB binary blob directly into a repo isn't great
  practice - it bloats every future clone, and git doesn't compress
  binaries well across rebuilds, so history size only grows.
- BETTER OPTION: commit the SOURCE files here (video_to_rt.py,
  build.bat, build_prepare.py, icon.ico, requirements.txt, this
  README) to the repo as normal text/small files, then zip up the
  built dist\vid2rt folder and attach that zip to a GitHub Release
  instead of committing it. Releases accept files up to 2 GB and
  don't bloat the repo's git history at all. On the repo's page:
  Releases → Draft a new release → attach the zip as a binary asset.
- If you DO want the built exe tracked in the repo itself anyway,
  use Git LFS for it (git lfs track "*.exe" and the _internal folder's
  larger files) rather than committing it as a normal blob.
- Either way, add a .gitignore excluding the PyInstaller `build/` and
  `dist/` folders and the `bin/` folder created during the build
  (these are regenerated by build.bat and don't need to be tracked) -
  otherwise anyone who runs build.bat in a cloned repo will end up
  wanting to commit gigabytes of intermediate PyInstaller cache files.

WHAT'S DIFFERENT FROM THE ORIGINAL vid2rt
-------------------------------------------
- No Node/Bun, no ImageMagick/GraphicsMagick install required — ffmpeg
  is bundled inside the app and frame decoding uses Pillow.
- A real point-and-click GUI instead of command-line flags.
- The character grid's aspect ratio is computed from the source
  video's actual resolution instead of a fixed 50x15.
- Frame rate is chosen per-video to stay under a total-frame budget
  that's confirmed to render correctly on YouTube (see above) -
  instead of a fixed fps that works for short clips and silently
  breaks on longer ones.
- Colours are quantized to one 32-colour palette built from the
  actual video, and same-colour pixels in a row are merged into one
  <font> tag, so files are smaller and faster to build.
- Handles cancelling, bad/unreadable files, and very long videos
  (warns you if the video is long enough that even the lowest frame
  rate would exceed the confirmed-safe frame budget).

TWEAKING IT
------------
Near the top of video_to_rt.py:
  GRID_COLS        — width of the ASCII grid in characters (default
                      32). Row count is derived automatically from the
                      video's aspect ratio.
  PALETTE_SIZE     — total distinct colours reused across the whole
                      video (default 32). Good for file size; wasn't
                      actually the cause of the rendering bug (see
                      above), so there's no strong evidence this can't
                      go higher, just no evidence it's safe either.
  MAX_TOTAL_FRAMES — THE important one. Total distinct frames allowed
                      across the whole video, regardless of length
                      (default 110 - confirmed working; 124 also
                      confirmed working, 138 confirmed broken, on a
                      ~27s test video). Raising this risks the video
                      rendering blank on YouTube again. If you do
                      raise it, test with a short throwaway video
                      first, the same way we tracked this down: try
                      it, and if it comes out blank, that's your
                      answer.
  MAX_FPS, MIN_FPS — hard ceiling/floor on frame rate regardless of
                      the budget above (defaults 10 and 1).
Edit, save, then re-run build.bat to rebuild.
