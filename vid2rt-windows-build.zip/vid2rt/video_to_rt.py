"""
vid2rt - Video to RealText (.rt) caption converter
-----------------------------------------------------
Pick a video, it renders every frame as a grid of coloured block
characters and writes a RealText (.rt) caption file where each cue is
one frame. YouTube's caption renderer honours <font color="#rrggbb">
inside .rt files (it explicitly does NOT honour it inside .srt - see
https://support.google.com/youtube/answer/2734698), so uploading this
as a caption track shows a small animated, colour video "inside" the
caption track.

This file is meant to be frozen with PyInstaller (see build.bat).
"""

import os
import re
import sys
import glob
import queue
import shutil
import tempfile
import threading
import subprocess

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from PIL import Image

# --------------------------------------------------------------------------
# Tunables - edit these if you want a different look / speed trade-off.
# --------------------------------------------------------------------------
GRID_COLS = 32          # width of the ASCII-art grid, in characters
PALETTE_SIZE = 32       # total distinct colours reused across the WHOLE
                        # video (built from the actual video's own colours).
                        # Keeps files smaller/more compressible - see
                        # MAX_TOTAL_FRAMES below for the setting that
                        # actually fixes the YouTube rendering bug.
MAX_TOTAL_FRAMES = 110  # THE IMPORTANT ONE. Direct testing on YouTube (see
                        # README) showed the caption renderer silently goes
                        # blank once a file contains too many genuinely
                        # DIFFERENT frames - NOT a colour or file-size limit
                        # (a static repeated frame, or a large but
                        # repetitive/predictable pattern, kept working fine
                        # no matter how big). For a 27-second clip, 110
                        # distinct frames confirmed working, 138 confirmed
                        # broken. Frame rate is therefore chosen per-video
                        # (see pick_fps) so THIS cap is respected regardless
                        # of how long the source video is, rather than using
                        # a fixed fps that would fail on longer videos.
                        # Don't raise this without retesting on YouTube.
MAX_FPS = 10            # never exceed this even for very short clips
MIN_FPS = 1             # never go below this even for very long clips
MIN_ROWS, MAX_ROWS = 8, 30
LONG_VIDEO_WARN_SECONDS = MAX_TOTAL_FRAMES / MIN_FPS  # past this length, even
                        # MIN_FPS can't keep the video under the frame budget
                        # above, so warn before producing a caption that may
                        # not render correctly on YouTube
FONT_SIZE = 12
FONT_FACE = "Arial"    # YouTube's renderer ignores this, but .rt files
                        # traditionally carry it - kept for fidelity

VIDEO_FILETYPES = [
    ("Video files", "*.mp4 *.mov *.mkv *.avi *.webm *.m4v *.wmv *.flv *.mpg *.mpeg"),
    ("All files", "*.*"),
]

APP_TITLE = "vid2rt"


# --------------------------------------------------------------------------
# ffmpeg helpers
# --------------------------------------------------------------------------
def get_ffmpeg_path():
    """Locate the ffmpeg binary, whether we're running frozen (PyInstaller)
    or straight from source (development)."""
    if getattr(sys, "frozen", False):
        base = getattr(sys, "_MEIPASS", os.path.dirname(sys.executable))
        exe_name = "ffmpeg.exe" if os.name == "nt" else "ffmpeg"
        bundled = os.path.join(base, "bin", exe_name)
        if os.path.exists(bundled):
            return bundled
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        pass
    return "ffmpeg"  # last resort: hope it's on PATH


def get_video_info(ffmpeg, path):
    """Return (duration_seconds_or_None, width_or_None, height_or_None)."""
    creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    proc = subprocess.run(
        [ffmpeg, "-i", path],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        creationflags=creationflags,
    )
    out = proc.stdout or ""

    duration = None
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+\.\d+)", out)
    if m:
        h, mnt, s = m.groups()
        duration = int(h) * 3600 + int(mnt) * 60 + float(s)

    width = height = None
    m = re.search(r"Video:.*?(\d{2,5})x(\d{2,5})", out)
    if m:
        width, height = int(m.group(1)), int(m.group(2))

    return duration, width, height


def extract_frames(ffmpeg, video_path, out_dir, fps, duration, progress_cb, cancel_event):
    """Runs ffmpeg to dump one jpg per subtitle frame into out_dir."""
    creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    cmd = [
        ffmpeg, "-y", "-i", video_path,
        "-vf", f"fps={fps}",
        "-progress", "pipe:1", "-nostats", "-loglevel", "error",
        os.path.join(out_dir, "frame_%06d.jpg"),
    ]
    proc = subprocess.Popen(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, bufsize=1, creationflags=creationflags,
    )
    try:
        for line in proc.stdout:
            if cancel_event.is_set():
                proc.terminate()
                break
            line = line.strip()
            if line.startswith("out_time=") and duration:
                ts = line.split("=", 1)[1]
                try:
                    hh, mm, ss = ts.split(":")
                    secs = int(hh) * 3600 + int(mm) * 60 + float(ss)
                    progress_cb(min(secs / duration, 1.0))
                except ValueError:
                    pass
            elif line.startswith("progress=") and "end" in line:
                progress_cb(1.0)
    finally:
        proc.wait()
    if cancel_event.is_set():
        raise InterruptedError("cancelled")
    if proc.returncode != 0:
        err = proc.stderr.read() if proc.stderr else ""
        raise RuntimeError(f"ffmpeg could not read that video.\n\n{err[-800:]}")


# --------------------------------------------------------------------------
# Frame -> coloured RealText cue
# --------------------------------------------------------------------------
def fmt_time_rt(seconds):
    """RealText timestamps look like 'MM:SS.mmm' (no hours component -
    matches what the original vid2rt tool emitted and what YouTube's
    .rt parser expects)."""
    total_ms = int(round(seconds * 1000))
    minutes, rem_ms = divmod(total_ms, 60_000)
    secs, ms = divmod(rem_ms, 1000)
    return f"{minutes:02d}:{secs:02d}.{ms:03d}"


def _span(color, length):
    return f'<font color="#{color[0]:02x}{color[1]:02x}{color[2]:02x}">{"█" * length}</font>'


def build_global_palette(frame_files, cols, rows, palette_size, sample_cb=None, max_samples=40):
    """Builds one shared colour palette from a spread of frames across the
    whole video, so every frame can later be quantized to the SAME set of
    <= palette_size colours (see PALETTE_SIZE note above)."""
    n = len(frame_files)
    step = max(1, n // max_samples)
    sample_files = frame_files[::step]

    tiles = []
    for f in sample_files:
        img = Image.open(f).convert("RGB").resize((cols, rows), Image.Resampling.BOX)
        tiles.append(img)

    sheet = Image.new("RGB", (cols, rows * len(tiles)))
    for i, t in enumerate(tiles):
        sheet.paste(t, (0, i * rows))

    return sheet.quantize(colors=palette_size, method=Image.Quantize.MEDIANCUT)


def frame_to_rows(path, cols, rows, palette_img):
    img = Image.open(path).convert("RGB").resize((cols, rows), Image.Resampling.BOX)
    img = img.quantize(palette=palette_img, dither=Image.Dither.NONE).convert("RGB")
    px = img.load()
    lines = []
    for y in range(rows):
        spans = []
        run_color, run_len = None, 0
        for x in range(cols):
            c = px[x, y]
            if c == run_color:
                run_len += 1
            else:
                if run_color is not None:
                    spans.append(_span(run_color, run_len))
                run_color, run_len = c, 1
        spans.append(_span(run_color, run_len))
        lines.append("".join(spans))
    return lines


def build_rt(frame_files, fps, cols, rows, progress_cb, cancel_event):
    """Builds a full RealText (.rt) document: one <time>/<clear/> cue per
    frame, each cue containing the frame's rows joined by <br/>."""
    palette_img = build_global_palette(frame_files, cols, rows, PALETTE_SIZE)

    cues = []
    n = len(frame_files)
    for i, f in enumerate(frame_files):
        if cancel_event.is_set():
            raise InterruptedError("cancelled")
        rows_text = frame_to_rows(f, cols, rows, palette_img)
        begin, end = fmt_time_rt(i / fps), fmt_time_rt((i + 1) / fps)
        cue_body = "<br/>".join(rows_text)
        cues.append(f'<time begin="{begin}" end="{end}"/><clear/>{cue_body}')
        progress_cb((i + 1) / n)

    body = "\n".join(cues)
    return (
        "<window>\n"
        f'<font size="{FONT_SIZE}" face="{FONT_FACE}">\n'
        f"{body}\n"
        "</font>\n"
        "</window>\n"
    )


def pick_grid_size(width, height):
    aspect = (width / height) if width and height else 16 / 9
    # 1.875 is the empirical character-cell aspect-compensation factor
    # (see README): rows = cols / (1.875 * aspect), derived from the
    # original tool's tuned 50x15 grid for 16:9 video.
    rows = round(GRID_COLS / (1.875 * aspect))
    rows = max(MIN_ROWS, min(MAX_ROWS, rows))
    return GRID_COLS, rows


def pick_fps(duration):
    """Chooses a frame rate so the WHOLE video never exceeds
    MAX_TOTAL_FRAMES distinct frames, regardless of its length - see the
    MAX_TOTAL_FRAMES comment above for why this matters more than fps
    itself."""
    if not duration or duration <= 0:
        return MAX_FPS
    fps = MAX_TOTAL_FRAMES / duration
    return max(MIN_FPS, min(MAX_FPS, fps))


# --------------------------------------------------------------------------
# GUI
# --------------------------------------------------------------------------
class App:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.resizable(False, False)
        self.root.geometry("460x230")
        self._center()

        self.cancel_event = threading.Event()
        self.msg_queue = queue.Queue()
        self.ffmpeg = get_ffmpeg_path()

        self._build_idle_view()
        self.root.after(200, self.choose_video)  # open the picker as soon as we launch
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    # ---- layout ---------------------------------------------------------
    def _center(self):
        self.root.update_idletasks()
        w, h = 460, 230
        x = (self.root.winfo_screenwidth() - w) // 2
        y = (self.root.winfo_screenheight() - h) // 2
        self.root.geometry(f"{w}x{h}+{x}+{y}")

    def _clear(self):
        for child in self.root.winfo_children():
            child.destroy()

    def _build_idle_view(self):
        self._clear()
        frame = tk.Frame(self.root, padx=24, pady=24)
        frame.pack(expand=True, fill="both")
        tk.Label(frame, text="vid2rt", font=("Segoe UI", 18, "bold")).pack(pady=(4, 2))
        tk.Label(
            frame,
            text="Turn any video into an animated, colour YouTube caption\n"
                 "file (.rt - RealText).",
            wraplength=380, justify="center",
        ).pack(pady=(0, 18))
        ttk.Button(frame, text="Choose Video…", command=self.choose_video).pack()

    def _build_progress_view(self):
        self._clear()
        frame = tk.Frame(self.root, padx=24, pady=24)
        frame.pack(expand=True, fill="both")

        self.stage_var = tk.StringVar(value="Choosing…")
        tk.Label(frame, textvariable=self.stage_var, font=("Segoe UI", 13, "bold")).pack(pady=(6, 14))

        self.progress = ttk.Progressbar(frame, length=380, mode="determinate", maximum=100)
        self.progress.pack(pady=(0, 8))

        self.pct_var = tk.StringVar(value="0%")
        tk.Label(frame, textvariable=self.pct_var).pack()

        self.cancel_btn = ttk.Button(frame, text="Cancel", command=self._cancel)
        self.cancel_btn.pack(pady=(18, 0))

    def _build_done_view(self, saved_path):
        self._clear()
        frame = tk.Frame(self.root, padx=24, pady=24)
        frame.pack(expand=True, fill="both")
        tk.Label(frame, text="Finished!!! :)", font=("Segoe UI", 16, "bold")).pack(pady=(4, 10))
        tk.Label(
            frame, text=f"Saved to:\n{saved_path}\n\n"
                        "Upload this in YouTube Studio under Subtitles →\n"
                        "Upload file → \"With timing\".",
            wraplength=400, justify="center"
        ).pack(pady=(0, 18))
        row = tk.Frame(frame)
        row.pack()
        ttk.Button(row, text="Convert Another Video", command=self.choose_video).pack(side="left", padx=6)
        ttk.Button(row, text="Exit", command=self.root.destroy).pack(side="left", padx=6)

    # ---- flow -------------------------------------------------------------
    def choose_video(self):
        path = filedialog.askopenfilename(title="Choose a video", filetypes=VIDEO_FILETYPES)
        if not path:
            self._build_idle_view()
            return
        self.video_path = path
        self.cancel_event = threading.Event()
        self._build_progress_view()
        self._set_stage("Analysing video…", 5)
        threading.Thread(target=self._worker, args=(path,), daemon=True).start()
        self.root.after(60, self._poll_queue)

    def _cancel(self):
        self.cancel_event.set()
        self.stage_var.set("Cancelling…")

    def _on_close(self):
        self.cancel_event.set()
        self.root.destroy()

    def _set_stage(self, text, pct):
        self.stage_var.set(text)
        self.progress["value"] = pct
        self.pct_var.set(f"{int(pct)}%")

    # ---- worker thread ------------------------------------------------
    def _worker(self, video_path):
        tmp_dir = tempfile.mkdtemp(prefix="vid2rt_")
        try:
            duration, width, height = get_video_info(self.ffmpeg, video_path)
            if duration is None:
                raise RuntimeError("Could not read that video. Is it a valid video file?")

            if duration > LONG_VIDEO_WARN_SECONDS:
                proceed = self._ask_confirm_long_video(duration)
                if not proceed:
                    self.msg_queue.put(("cancelled", None))
                    return

            cols, rows = pick_grid_size(width, height)
            fps = pick_fps(duration)

            self.msg_queue.put(("stage", ("Saving frames…", 10)))

            def extract_progress(frac):
                self.msg_queue.put(("progress", 10 + frac * 45))

            extract_frames(self.ffmpeg, video_path, tmp_dir, fps, duration,
                            extract_progress, self.cancel_event)

            frame_files = sorted(glob.glob(os.path.join(tmp_dir, "*.jpg")))
            if not frame_files:
                raise RuntimeError("No frames were extracted from that video.")

            self.msg_queue.put(("stage", ("Converting frames…", 55)))

            def convert_progress(frac):
                self.msg_queue.put(("progress", 55 + frac * 44))

            rt_text = build_rt(frame_files, fps, cols, rows,
                                convert_progress, self.cancel_event)

            self.msg_queue.put(("stage", ("Finished!!! :)", 100)))
            self.msg_queue.put(("finished", (rt_text, video_path)))

        except InterruptedError:
            self.msg_queue.put(("cancelled", None))
        except Exception as exc:  # noqa: BLE001 - surface any failure to the UI
            self.msg_queue.put(("error", str(exc)))
        finally:
            shutil.rmtree(tmp_dir, ignore_errors=True)

    def _ask_confirm_long_video(self, duration):
        # Runs on the worker thread: hand the question to the main thread via
        # the queue (thread-safe) and block here for its answer, rather than
        # touching any Tk widget/method directly from this thread.
        response = queue.Queue()
        self.msg_queue.put(("confirm_long_video", (duration, response)))
        return bool(response.get())

    # ---- main-thread queue polling -------------------------------------
    def _poll_queue(self):
        try:
            while True:
                kind, payload = self.msg_queue.get_nowait()
                if kind == "stage":
                    text, pct = payload
                    self._set_stage(text, pct)
                elif kind == "progress":
                    pct = max(0, min(100, payload))
                    self.progress["value"] = pct
                    self.pct_var.set(f"{int(pct)}%")
                elif kind == "finished":
                    rt_text, video_path = payload
                    self._save_rt(rt_text, video_path)
                    return
                elif kind == "cancelled":
                    self._build_idle_view()
                    return
                elif kind == "error":
                    messagebox.showerror(APP_TITLE, payload)
                    self._build_idle_view()
                    return
                elif kind == "confirm_long_video":
                    duration, response = payload
                    minutes = duration / 60
                    ok = messagebox.askyesno(
                        APP_TITLE,
                        f"This video is about {minutes:.0f} minutes long.\n"
                        "Past this length, even the slowest frame rate this "
                        "app allows produces more distinct frames than "
                        "YouTube's caption renderer has been confirmed to "
                        "handle reliably - the result may play back blank "
                        "or partly blank.\n\nContinue anyway?",
                    )
                    response.put(ok)
        except queue.Empty:
            pass
        self.root.after(60, self._poll_queue)

    def _save_rt(self, rt_text, video_path):
        base = os.path.splitext(os.path.basename(video_path))[0]
        path = filedialog.asksaveasfilename(
            title="Save caption file",
            defaultextension=".rt",
            initialfile=f"{base}.rt",
            filetypes=[("RealText Subtitle", "*.rt"), ("All files", "*.*")],
        )
        if not path:
            self._build_idle_view()
            return
        try:
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(rt_text)
        except OSError as exc:
            messagebox.showerror(APP_TITLE, f"Could not save the file:\n{exc}")
            self._build_idle_view()
            return
        self._build_done_view(path)


def main():
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
