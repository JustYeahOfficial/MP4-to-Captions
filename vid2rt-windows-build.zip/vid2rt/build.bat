@echo off
setlocal
cd /d "%~dp0"

echo ============================================
echo   vid2rt - Windows build script
echo ============================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo ERROR: Python was not found on PATH.
    echo Install Python 3.10 or newer from python.org and make sure
    echo "Add python.exe to PATH" is checked during setup, then try again.
    pause
    exit /b 1
)

echo Installing build dependencies ^(pyinstaller, pillow, imageio-ffmpeg^)...
python -m pip install --upgrade pip >nul
python -m pip install --upgrade pyinstaller pillow imageio-ffmpeg
if errorlevel 1 (
    echo ERROR: pip install failed. Check your internet connection and try again.
    pause
    exit /b 1
)

echo.
echo Bundling a portable ffmpeg.exe...
python build_prepare.py
if errorlevel 1 (
    echo ERROR: could not prepare the ffmpeg binary.
    pause
    exit /b 1
)

echo.
echo Cleaning up any previous build...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist vid2rt.spec del /q vid2rt.spec

echo.
echo Building vid2rt.exe  (this can take a minute or two)...
python -m PyInstaller --name vid2rt --windowed --onedir --icon icon.ico --add-binary "bin\ffmpeg.exe;bin" --exclude-module numpy --exclude-module scipy --exclude-module imageio_ffmpeg video_to_rt.py
if errorlevel 1 (
    echo ERROR: PyInstaller build failed. See the messages above.
    pause
    exit /b 1
)

echo.
echo ============================================
echo   Build complete!
echo.
echo   Your app is in:   dist\vid2rt\
echo   It contains ONLY vid2rt.exe and the _internal folder -
echo   copy that whole folder wherever you like and run vid2rt.exe.
echo ============================================
echo.
pause
