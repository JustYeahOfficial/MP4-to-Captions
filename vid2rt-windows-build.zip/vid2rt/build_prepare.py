"""Copies the ffmpeg binary that pip just downloaded (via imageio-ffmpeg)
into ./bin so PyInstaller can bundle it inside the app."""
import os
import shutil

import imageio_ffmpeg

os.makedirs("bin", exist_ok=True)
src = imageio_ffmpeg.get_ffmpeg_exe()
dst_name = "ffmpeg.exe" if os.name == "nt" else "ffmpeg"
dst = os.path.join("bin", dst_name)
shutil.copy(src, dst)
if os.name != "nt":
    os.chmod(dst, 0o755)
print(f"Bundled ffmpeg: {src} -> {dst}")
